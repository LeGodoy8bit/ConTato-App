package contato.app.presentation.communicator

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import contato.app.domain.model.Message
import contato.app.domain.model.MessageStatus
import contato.app.domain.model.UserMode
import contato.app.domain.state.ConnectionState
import contato.app.presentation.theme.ContatoIcons
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ───────────────────────── Conversa aberta ─────────────────────────

/** Item da lista: separador de dia ("Hoje") ou balão. */
private sealed interface ChatItem {
    val key: String
    /** [position] entra na chave: dois "12 de outubro" de anos diferentes não repetem a chave. */
    data class Day(val label: String, val position: Int) : ChatItem { override val key get() = "day-$position-$label" }
    data class Bubble(val message: Message) : ChatItem { override val key get() = message.id }
}

/**
 * Uma conversa aberta (referência "UX/UI Design Squad"): voltar, nome e status no topo,
 * separadores de dia, balões e o campo de mensagem.
 * Conversas antigas (de um aparelho que não está conectado) abrem só para leitura.
 */
@Composable
internal fun ChatDetail(
    session: CommunicatorSession,
    conversationId: String,
    c: CommColors,
    onBack: () -> Unit,
    onOpenInfo: () -> Unit,
) {
    val conversation = session.conversation(conversationId)
    val messages = session.messagesOf(conversationId)
    val isActive = conversationId == session.activeConversationId
    val canWrite = session.canWriteTo(conversationId)
    val listState = rememberLazyListState()

    val items = remember(messages.toList()) {
        buildList<ChatItem> {
            var lastDay = ""
            messages.forEach { m ->
                val day = dayLabel(m.timestamp)
                if (day != lastDay) { add(ChatItem.Day(day, size)); lastDay = day }
                add(ChatItem.Bubble(m))
            }
        }
    }

    // Rola para a última mensagem e marca como lida quando chega ou sai uma nova.
    LaunchedEffect(conversationId, messages.size) {
        if (items.isNotEmpty()) listState.animateScrollToItem(items.lastIndex)
        session.markRead(conversationId)
    }

    Column(Modifier.fillMaxSize()) {
        ChatHeader(
            name = conversation?.peerName ?: session.peerName ?: CommunicatorSession.DEFAULT_PEER,
            state = if (isActive) session.connectionState else ConnectionState.DISCONNECTED,
            isActive = isActive,
            c = c,
            onBack = onBack,
            onOpenInfo = onOpenInfo,
        )

        AnimatedVisibility(visible = !canWrite) {
            if (isActive) OfflineBar(session.connectionState, c, onSearch = session::searchAgain)
            else ReadOnlyBar(conversation?.peerName ?: "este aparelho", c, onPair = session::searchAgain)
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (messages.isEmpty()) {
                EmptyChat(c, Modifier.align(Alignment.Center))
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(items, key = { it.key }) { item ->
                        Box(Modifier.animateItem()) {
                            when (item) {
                                is ChatItem.Day -> DaySeparator(item.label, c)
                                is ChatItem.Bubble -> MessageBubble(item.message, session.progress[item.message.id], c)
                            }
                        }
                    }
                }
            }
        }

        if (isActive) MessageInput(enabled = canWrite, c = c, onSend = session::send)
    }
}

@Composable
private fun ChatHeader(
    name: String,
    state: ConnectionState,
    isActive: Boolean,
    c: CommColors,
    onBack: () -> Unit,
    onOpenInfo: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Voltar num quadrado arredondado (referência).
        Box(
            Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(c.surface)
                .border(1.dp, c.border, RoundedCornerShape(16.dp))
                .clickable(role = Role.Button, onClickLabel = "Voltar para as conversas", onClick = onBack),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Voltar", tint = c.onSurface)
        }
        Spacer(Modifier.width(12.dp))
        PeerAvatar(name, 44.dp, c, online = isActive && state == ConnectionState.CONNECTED)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f).semantics(mergeDescendants = true) {}) {
            Text(name, color = c.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.titleMedium.copy(fontSize = 17.sp, lineHeight = 22.sp, fontWeight = FontWeight.Bold))
            AnimatedContent(
                targetState = when {
                    !isActive -> "Histórico"
                    state == ConnectionState.CONNECTED -> "Conectado"
                    else -> connectionLabel(state, null)
                },
                transitionSpec = { textSwapTransition() },
                label = "headerStatus",
            ) { t ->
                Text(t, color = c.muted, style = MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp, lineHeight = 18.sp))
            }
        }
        IconButton(onClick = onOpenInfo) {
            Icon(Icons.Default.Info, contentDescription = "Sobre o ConTato e matriz Braille", tint = c.onSurface)
        }
    }
}

@Composable
private fun DaySeparator(label: String, c: CommColors) {
    Box(Modifier.fillMaxWidth().padding(vertical = 4.dp), contentAlignment = Alignment.Center) {
        Text(label, color = c.muted, modifier = Modifier.semantics { heading() },
            style = MaterialTheme.typography.labelLarge.copy(fontSize = 13.sp, fontWeight = FontWeight.Medium))
    }
}

/** Conversa antiga: avisa que para responder é preciso conectar com aquele aparelho. */
@Composable
private fun ReadOnlyBar(peer: String, c: CommColors, onPair: () -> Unit) {
    Row(
        Modifier
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(c.accentSoft)
            .padding(start = 14.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            "Para continuar, conecte de novo com $peer.",
            color = c.onSurface,
            modifier = Modifier.weight(1f).padding(vertical = 10.dp),
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp, lineHeight = 18.sp),
        )
        TextButton(onClick = onPair, modifier = Modifier.heightIn(min = 48.dp)) {
            Text("Parear", color = c.accent, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun OfflineBar(state: ConnectionState, c: CommColors, onSearch: () -> Unit) {
    val searching = state != ConnectionState.DISCONNECTED && state != ConnectionState.CONNECTION_ERROR
    Row(
        Modifier
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(c.searching.copy(alpha = 0.14f))
            .padding(start = 14.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            if (searching) "Procurando o celular tátil. As mensagens saem quando conectar."
            else "Sem conexão com o celular tátil.",
            color = c.onSurface,
            modifier = Modifier.weight(1f).padding(vertical = 10.dp),
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp, lineHeight = 18.sp),
        )
        if (!searching) {
            TextButton(onClick = onSearch, modifier = Modifier.heightIn(min = 48.dp)) {
                Icon(Icons.Default.Refresh, null, tint = c.accent, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Procurar", color = c.accent, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun EmptyChat(c: CommColors, modifier: Modifier) {
    Column(modifier.padding(horizontal = 40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(64.dp).clip(CircleShape).background(c.accent.copy(alpha = 0.12f)), contentAlignment = Alignment.Center) {
            Icon(ContatoIcons.ChatBubble, null, tint = c.accent, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text("Nenhuma mensagem ainda", color = c.onSurface,
            style = MaterialTheme.typography.titleMedium.copy(fontSize = 18.sp, fontWeight = FontWeight.Bold))
        Spacer(Modifier.height(6.dp))
        Text(
            "Prefira frases curtas: cada letra leva cerca de 2 segundos para vibrar.",
            color = c.muted,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 14.sp, lineHeight = 20.sp),
        )
    }
}

// ───────────────────────── Balões ─────────────────────────

private val timeFormat = SimpleDateFormat("HH:mm", Locale.forLanguageTag("pt-BR"))

@Composable
private fun MessageBubble(message: Message, progress: PlaybackProgress?, c: CommColors) {
    val mine = message.sender == UserMode.COMMUNICATOR
    val time = remember(message.timestamp) { timeFormat.format(Date(message.timestamp)) }
    Column(
        Modifier.fillMaxWidth(),
        horizontalAlignment = if (mine) Alignment.End else Alignment.Start,
    ) {
        Column(
            Modifier
                .widthIn(max = 300.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = 20.dp, topEnd = 20.dp,
                        bottomStart = if (mine) 20.dp else 6.dp,
                        bottomEnd = if (mine) 6.dp else 20.dp,
                    )
                )
                .background(if (mine) c.sent else c.received)
                .then(if (mine || c.dark) Modifier else Modifier.border(1.dp, c.border, RoundedCornerShape(20.dp, 20.dp, 20.dp, 6.dp)))
                .padding(horizontal = 14.dp, vertical = 10.dp),
        ) {
            // Enquanto vibra, a letra atual fica destacada dentro do próprio balão.
            if (mine && message.status == MessageStatus.PLAYING && progress != null) {
                ProgressText(progress, c)
            } else {
                Text(message.content, color = if (mine) c.onSent else c.onReceived,
                    style = MaterialTheme.typography.bodyLarge.copy(fontSize = 16.sp, lineHeight = 22.sp))
            }
            Text(time, color = (if (mine) c.onSent else c.muted).copy(alpha = 0.8f),
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                modifier = Modifier.align(Alignment.End).padding(top = 2.dp))
        }
        if (mine) {
            Spacer(Modifier.height(4.dp))
            StatusChip(message.status, progress, c)
        }
    }
}

/** Texto normalizado com a letra que está vibrando agora em destaque; as já sentidas ficam mais claras. */
@Composable
private fun ProgressText(progress: PlaybackProgress, c: CommColors) {
    val text = buildAnnotatedString {
        progress.text.forEachIndexed { i, ch ->
            when {
                i < progress.index -> withStyle(SpanStyle(color = c.onSent.copy(alpha = 0.6f))) { append(ch) }
                i == progress.index -> withStyle(
                    SpanStyle(color = c.sent, background = Color.White, fontWeight = FontWeight.Bold)
                ) { append(if (ch == ' ') '·' else ch) }
                else -> withStyle(SpanStyle(color = c.onSent)) { append(ch) }
            }
        }
    }
    Text(
        text,
        style = MaterialTheme.typography.bodyLarge.copy(fontSize = 17.sp, lineHeight = 24.sp, letterSpacing = 1.sp),
        modifier = Modifier.semantics {
            contentDescription = "Vibrando letra ${progress.index + 1} de ${progress.total}"
        },
    )
}

// ───────────────────────── Campo de mensagem ─────────────────────────

@Composable
private fun MessageInput(enabled: Boolean, c: CommColors, onSend: (String) -> Boolean) {
    var text by rememberSaveable { mutableStateOf("") }
    val canSend = enabled && text.isNotBlank()
    val hasUnsupported = text.any { it.isDigit() || (!it.isLetter() && !it.isWhitespace()) }

    fun send() {
        if (canSend && onSend(text)) text = ""
    }

    Column(Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 8.dp)) {
        if (hasUnsupported) {
            Text("Números e pontuação não vibram; só as letras serão sentidas.", color = c.muted,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                modifier = Modifier.padding(start = 12.dp, bottom = 4.dp))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Row(
                Modifier
                    .weight(1f)
                    .heightIn(min = 52.dp)
                    .clip(CircleShape)
                    .background(c.surface)
                    .border(1.dp, c.border, CircleShape)
                    .padding(start = 18.dp, end = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.weight(1f).padding(vertical = 12.dp)) {
                    if (text.isEmpty()) {
                        Text(if (enabled) "Escreva uma mensagem" else "Aguardando conexão",
                            color = c.muted, style = MaterialTheme.typography.bodyLarge.copy(fontSize = 16.sp))
                    }
                    BasicTextField(
                        value = text,
                        onValueChange = { if (it.length <= CommunicatorSession.MAX_LENGTH) text = it },
                        enabled = enabled,
                        textStyle = TextStyle(color = c.onSurface, fontSize = 16.sp, lineHeight = 22.sp),
                        cursorBrush = SolidColor(c.accent),
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences, imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { send() }),
                        maxLines = 3,
                        modifier = Modifier.fillMaxWidth().semantics { contentDescription = "Mensagem" },
                    )
                }
                Text("${text.length}/${CommunicatorSession.MAX_LENGTH}", color = c.muted,
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 12.sp))
            }
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(if (canSend) c.sent else c.border)
                    .clickable(enabled = canSend, role = Role.Button, onClickLabel = "Enviar mensagem") { send() },
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Enviar",
                    tint = if (canSend) Color.White else c.muted, modifier = Modifier.size(22.dp))
            }
        }
    }
}
