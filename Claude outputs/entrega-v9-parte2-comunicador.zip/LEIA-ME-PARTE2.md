# ConTato v9 — Parte 2 (Comunicador) + ajustes da cela e do treino

Extraia o zip, copie a pasta `app` para dentro de ConTatoApp e escolha
"Substituir os arquivos no destino". Já inclui tudo da Parte 1.

Pastas/arquivos NOVOS (são criados sozinhos ao colar):
- app/src/main/res/drawable/ill_*.xml (6 ilustrações)
- presentation/common/Illustration.kt
- presentation/communicator/AiIntroScreen.kt
- presentation/deafblind/DeafblindGesturePad.kt
- domain/service/TimeEstimates.kt
- test: TimeEstimatesTest.kt (e HapticMessageServiceTest.kt atualizado)

Testar:
1. Surdocego: bolas maiores e mais juntas; tocar não mostra mais o quadrado.
2. Treino: aparece a página "Faça junto com a pessoa de apoio" e os gestos funcionam
   (toque, ← → ↑ ↓). ↓ repete a letra.
3. Comunicador abre sempre em Conversas. "Conectar" (aba Conexão ou +) abre a tela nova.
4. Ao digitar: contador /80 e o tempo para sentir. Ao enviar: "Sentindo a mensagem · faltam ~X s",
   depois "Aguardando a resposta · costuma levar ~1 min".
5. Saia e entre na conta (Ajustes): aparece a apresentação da IA. Também em Ajustes > Como funciona a IA.
6. A conversa "Letícia" duplicada se junta sozinha ao abrir o app.
