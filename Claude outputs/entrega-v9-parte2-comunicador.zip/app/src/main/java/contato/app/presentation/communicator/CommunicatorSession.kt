package contato.app.presentation.communicator

import android.content.Context
import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import contato.app.data.ProfilePhotoStore
import contato.app.domain.model.MessageStyle
import androidx.compose.runtime.derivedStateOf
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import contato.app.core.ai.LlamaTextSimplifier
import contato.app.core.config.HapticConfig
import contato.app.domain.repository.AiStatus
import contato.app.domain.repository.SimplifyResult
import contato.app.domain.repository.TextSimplifier
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import contato.app.core.connection.NearbyConnectionService
import contato.app.core.connection.NearbyListener
import contato.app.core.vibration.HapticMessagePlaybackService
import contato.app.domain.model.Conversation
import contato.app.domain.model.Message
import contato.app.domain.model.MessageStatus
import contato.app.domain.model.UserMode
import contato.app.domain.model.WireMessage
import contato.app.domain.repository.CommunicatorProfileRepository
import contato.app.domain.repository.ConversationArchive
import contato.app.domain.service.BrailleTextNormalizer
import contato.app.domain.service.SimplificationRules
import contato.app.domain.service.TimeEstimates
import contato.app.domain.service.ConversationMerger
import contato.app.domain.service.WireProtocol
import contato.app.domain.state.ConnectionState
import contato.app.domain.state.ConversationState
import contato.app.domain.state.ConversationStateMachine
import contato.app.presentation.common.CloudAccount
import java.util.UUID

/** Em que letra o celular do Surdocego está agora (texto já normalizado: A-Z e espaço). */
internal data class PlaybackProgress(val index: Int, val text: String) {
    val total: Int get() = text.length
    val character: Char? get() = text.getOrNull(index)
}

internal enum class BannerKind { SUCCESS, ERROR }

/** Aviso no topo da tela (conectado, conexão perdida...). [key] força reexibir avisos iguais. */
internal data class Banner(
    val kind: BannerKind,
    val title: String,
    val message: String,
    val key: Long = System.nanoTime(),
)

/**
 * Estado e regras da sessão do Comunicador: conexão, conversa, status de cada mensagem
 * e preferências. As telas Compose só leem estes campos e chamam estas funções.
 *
 * Não é um ViewModel de propósito (o projeto não usa a biblioteca de ViewModel). Vive
 * enquanto a CommunicatorActivity vive; a Activity não é recriada ao girar a tela
 * (configChanges no Manifest), então a conexão também não cai por isso.
 */
internal class CommunicatorSession(
    context: Context,
    private val profile: CommunicatorProfileRepository,
    private val archive: ConversationArchive,
    val account: CloudAccount,
) : NearbyListener {

    private val nearby = NearbyConnectionService(context, this)
    private val playback = HapticMessagePlaybackService(context)
    private val conversation = ConversationStateMachine()
    private val handler = Handler(Looper.getMainLooper())

    var connectionState by mutableStateOf(ConnectionState.DISCONNECTED)
        private set
    var peerName by mutableStateOf<String?>(null)
        private set
    var displayName by mutableStateOf(profile.getDisplayName())
        private set
    var historyEnabled by mutableStateOf(profile.isHistoryEnabled())
        private set
    var autoSearchEnabled by mutableStateOf(profile.isAutoSearchEnabled())
        private set
    var banner by mutableStateOf<Banner?>(null)

    /** Cor dos balões, tamanho do texto e horários (Ajustes → Estilo das mensagens). */
    var messageStyle by mutableStateOf(profile.getMessageStyle())
        private set

    /** Foto de perfil (só neste celular). */
    var photo by mutableStateOf<ImageBitmap?>(null)
        private set
    private val photoStore = ProfilePhotoStore(context)

    /** Já conectou alguma vez nesta sessão? (para não voltar à tela de conexão sozinho). */
    var hasConnected by mutableStateOf(false)
        private set

    /** Todas as conversas (uma por aparelho), mais recente primeiro. */
    val conversations = mutableStateListOf<Conversation>()

    /** Conversa do aparelho conectado agora (ou do último conectado). */
    var activeConversationId by mutableStateOf<String?>(null)
        private set

    /** Mensagens da conversa ativa, atualizadas ao vivo (status, letra vibrando...). */
    val messages = mutableStateListOf<Message>()
    val progress = mutableStateMapOf<String, PlaybackProgress>()

    /** Total de mensagens não lidas (bolinha na aba Conversas). */
    val unreadTotal by derivedStateOf { conversations.sumOf { it.unreadCount(UserMode.COMMUNICATOR) } }

    private var started = false
    private var autoReconnect = true

    // ───────── IA (simplificação no próprio celular) ─────────

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val simplifier: TextSimplifier = LlamaTextSimplifier.get(context)

    /** Preferência "Simplificar mensagens com IA". */
    var aiEnabled by mutableStateOf(profile.isAiEnabled())
        private set
    var aiStatus by mutableStateOf(AiStatus.OFF)
        private set

    init {
        loadPhotoInBackground()
        // merge com lista vazia também junta duplicadas antigas (ex.: duas "Letícia").
        if (historyEnabled) conversations.addAll(ConversationMerger.merge(archive.loadAll(), emptyList()))
        if (account.isSignedIn && historyEnabled) pullCloud(pushAfter = false)
        if (aiEnabled) prepareAi()
    }

    fun updateAiEnabled(enabled: Boolean) {
        aiEnabled = enabled
        profile.setAiEnabled(enabled)
        if (enabled) prepareAi() else {
            simplifier.unload()
            aiStatus = AiStatus.OFF
        }
    }

    private fun prepareAi() {
        if (aiStatus == AiStatus.PREPARING || aiStatus == AiStatus.READY) return
        aiStatus = AiStatus.PREPARING
        scope.launch {
            val result = simplifier.prepare()
            // Se desligaram enquanto carregava, solta o modelo de novo.
            if (aiEnabled) aiStatus = result else simplifier.unload()
        }
    }

    /** Apresentação da IA (páginas com ilustrações), mostrada uma vez depois de entrar na conta. */
    var showAiIntro by mutableStateOf(false)
        private set

    fun openAiIntro() { showAiIntro = true }

    /** Fim da apresentação: [enable] = a pessoa tocou em "Ativar a IA". */
    fun finishAiIntro(enable: Boolean) {
        showAiIntro = false
        profile.setAiIntroSeen()
        if (enable && !aiEnabled) updateAiEnabled(true)
    }

    // ───────── Tempo estimado (sentir a mensagem e receber a resposta) ─────────

    /** O que mostrar acima do campo de texto: sentindo (com hora prevista de fim) ou aguardando resposta. */
    sealed interface ChatEstimate {
        data class Feeling(val messageId: String, val endsAt: Long) : ChatEstimate
        data class Waiting(val since: Long, val typicalMs: Long) : ChatEstimate
    }

    var chatEstimate by mutableStateOf<ChatEstimate?>(null)
        private set

    /** Velocidade real da vibração no outro celular (1 = padrão), medida durante a leitura. */
    private var feelScale = 1f
    private var firstProgress: Triple<String, Int, Long>? = null
    private var playedAt: Long? = null
    private val replySamples = mutableListOf<Long>()

    /** Tempo para sentir este texto, já na velocidade medida do outro celular. */
    fun feelEstimateMs(text: String): Long = (TimeEstimates.feelMs(text) * feelScale).toLong()

    private fun estimateOnSend(id: String, text: String) {
        chatEstimate = ChatEstimate.Feeling(id, System.currentTimeMillis() + feelEstimateMs(text))
    }

    private fun estimateOnProgress(id: String, index: Int, text: String) {
        val now = System.currentTimeMillis()
        val first = firstProgress
        if (first == null || first.first != id) {
            firstProgress = Triple(id, index, now)
        } else {
            TimeEstimates.measureScale(text, first.second, index, now - first.third)?.let { feelScale = it }
        }
        chatEstimate = ChatEstimate.Feeling(id, now + TimeEstimates.remainingFeelMs(text, index, feelScale))
    }

    private fun estimateOnPlayed(id: String) {
        // Só a última mensagem enviada conta para "aguardando resposta".
        val last = messages.lastOrNull { it.sender == UserMode.COMMUNICATOR }
        if (last?.id != id) return
        playedAt = System.currentTimeMillis()
        chatEstimate = ChatEstimate.Waiting(playedAt!!, TimeEstimates.typicalReplyMs(replySamples))
    }

    private fun estimateOnReply() {
        playedAt?.let { replySamples += System.currentTimeMillis() - it }
        playedAt = null
        chatEstimate = null
    }

    // ───────── Tela de conexão (só quando a pessoa pede) ─────────

    /** Aumenta quando conecta pela tela de conexão: a tela principal abre a conversa daquele aparelho. */
    var openChatRequest by mutableStateOf(0)
        private set

    fun requestOpenChat() { openChatRequest++ }

    /** Se a IA está pronta e a frase é longa o bastante para valer a pena. */
    fun canSimplify(text: String): Boolean =
        aiEnabled && aiStatus == AiStatus.READY && SimplificationRules.shouldSimplify(text)

    /** Pede à IA uma versão mais curta (sem ganho, erro e demora vêm como NoGain/Failed). */
    suspend fun simplify(text: String): SimplifyResult =
        if (aiStatus == AiStatus.READY) simplifier.simplify(text) else SimplifyResult.Failed

    // ───────── Conversas ─────────

    fun conversation(id: String): Conversation? = conversations.firstOrNull { it.id == id }

    /** Mensagens para a tela de uma conversa: a ativa vem ao vivo, as outras do histórico. */
    fun messagesOf(id: String): List<Message> =
        if (id == activeConversationId) messages else conversation(id)?.messages.orEmpty()

    /** Só dá para escrever na conversa do aparelho que está conectado agora. */
    fun canWriteTo(id: String): Boolean =
        id == activeConversationId && connectionState == ConnectionState.CONNECTED

    fun markRead(id: String) {
        val i = conversations.indexOfFirst { it.id == id }
        if (i < 0) return
        val c = conversations[i]
        val last = c.lastMessage?.timestamp ?: return
        if (c.lastReadAt >= last) return
        conversations[i] = c.copy(lastReadAt = last)
        persist(conversations[i], emptyList())
    }

    /** Ao conectar: abre (ou cria) a conversa com aquele aparelho. */
    private fun activateConversationFor(peer: String) {
        val key = ConversationMerger.peerKey(peer)
        val existing = conversations.firstOrNull { ConversationMerger.peerKey(it.peerName) == key }
        val conversation = existing ?: Conversation(
            id = UUID.randomUUID().toString(),
            peerName = peer,
            messages = emptyList(),
            updatedAt = System.currentTimeMillis(),
        ).also { conversations.add(0, it) }
        activeConversationId = conversation.id
        messages.clear()
        messages.addAll(conversation.messages)
        progress.clear()
    }

    /** Copia a conversa ativa para a lista, salva no aparelho e manda o que mudou para a nuvem. */
    private fun commitActive(changed: List<Message>) {
        val id = activeConversationId ?: return
        val i = conversations.indexOfFirst { it.id == id }
        if (i < 0) return
        val updated = conversations[i].copy(
            messages = messages.toList(),
            updatedAt = messages.lastOrNull()?.timestamp ?: conversations[i].updatedAt,
        )
        conversations.removeAt(i)
        conversations.add(0, updated)
        persist(updated, changed)
    }

    private fun persist(conversation: Conversation, changed: List<Message>) {
        if (!historyEnabled) return
        archive.saveAll(conversations.toList())
        // Status intermediário (letra a letra) não vai para a nuvem: economiza gravações.
        val relevant = changed.filter { it.status != MessageStatus.PLAYING && it.status != MessageStatus.SENDING }
        account.push(conversation, relevant)
    }

    // ───────── Conta (Firebase) ─────────

    /** "Continuar com Google". Ao entrar, junta as conversas do aparelho com as da nuvem. */
    fun signIn(activityContext: Context) {
        account.launchSignIn(activityContext) {
            // Já tinha conta: traz nome e preferências salvos; depois grava o estado atual.
            account.fetchProfile { cloud ->
                if (cloud != null) {
                    if (cloud.displayName.isNotBlank()) rename(cloud.displayName)
                    cloud.preferences["autoSearch"]?.toBooleanStrictOrNull()?.let { if (it != autoSearchEnabled) setAutoSearch(it) }
                }
                syncProfile()
            }
            if (!historyEnabled) setHistory(true) // entrar para salvar já liga o "Guardar conversas"
            pullCloud(pushAfter = true)
            banner = Banner(BannerKind.SUCCESS, "Conta conectada", "Suas conversas agora ficam salvas na nuvem.")
            if (!profile.isAiIntroSeen()) showAiIntro = true
        }
    }

    fun signOut(activityContext: Context) {
        account.launchSignOut(activityContext) {
            banner = Banner(BannerKind.SUCCESS, "Você saiu da conta", "As conversas continuam neste aparelho.")
        }
    }

    private fun pullCloud(pushAfter: Boolean) {
        account.pull { remote ->
            val activePeer = conversation(activeConversationId ?: "")?.peerName
            val merged = ConversationMerger.merge(conversations.toList(), remote)
            conversations.clear()
            conversations.addAll(merged)
            // A conversa ativa pode ter ganhado o id da nuvem e mensagens antigas.
            if (activePeer != null) {
                val key = ConversationMerger.peerKey(activePeer)
                merged.firstOrNull { ConversationMerger.peerKey(it.peerName) == key }?.let { c ->
                    activeConversationId = c.id
                    val live = messages.associateBy { it.id }
                    messages.clear()
                    messages.addAll(ConversationMerger.mergeMessages(c.messages, live.values.toList()))
                }
            }
            archive.saveAll(merged)
            if (pushAfter) merged.forEach { account.push(it, it.messages) }
        }
    }

    // ───────── Conexão ─────────

    /** Chamado quando as permissões estão concedidas. Procura sozinho se a busca automática estiver ligada. */
    fun start() {
        if (started) return
        started = true
        autoReconnect = autoSearchEnabled
        if (autoSearchEnabled) nearby.startAdvertising(displayName)
    }

    /** Modo de pareamento ("Parear agora"): recomeça a busca do zero, mesmo com a busca automática desligada. */
    fun searchAgain() {
        autoReconnect = true
        handler.removeCallbacksAndMessages(RECONNECT_TOKEN)
        if (nearby.getCurrentState() != ConnectionState.DISCONNECTED) nearby.stop()
        nearby.startAdvertising(displayName)
    }

    /** Botão "Desconectar": encerra e NÃO volta a procurar sozinho. */
    fun disconnect() {
        autoReconnect = false
        handler.removeCallbacksAndMessages(RECONNECT_TOKEN)
        nearby.stop()
    }

    /** Fim da Activity. */
    fun release() {
        scope.cancel()
        simplifier.unload() // solta a memória do modelo (~300 MB) ao sair
        account.release()
        started = false
        autoReconnect = false
        handler.removeCallbacksAndMessages(null)
        playback.stop()
        nearby.stop()
    }

    private fun scheduleReconnect() {
        if (!started || !autoReconnect) return
        handler.removeCallbacksAndMessages(RECONNECT_TOKEN)
        handler.postAtTime({
            if (started && autoReconnect && nearby.getCurrentState() == ConnectionState.DISCONNECTED) {
                nearby.startAdvertising(displayName)
            }
        }, RECONNECT_TOKEN, android.os.SystemClock.uptimeMillis() + RECONNECT_DELAY_MS)
    }

    // ───────── Mensagens ─────────

    /** Envia uma mensagem. Devolve false se não foi possível (sem conexão, sem letras). */
    fun send(raw: String): Boolean {
        val text = raw.trim().take(MAX_LENGTH)
        if (text.isEmpty() || connectionState != ConnectionState.CONNECTED) return false
        val normalized = BrailleTextNormalizer.normalizeForBraille(text)
        if (normalized.isEmpty()) {
            banner = Banner(BannerKind.ERROR, "Mensagem sem letras", "O ConTato vibra apenas letras de A a Z.")
            return false
        }
        // Raro, mas "ß" vira "SS": o texto que vibra pode ficar maior que o digitado.
        if (normalized.length > MAX_LENGTH) {
            banner = Banner(BannerKind.ERROR, "Mensagem longa demais", "Encurte um pouco a mensagem.")
            return false
        }

        // Uma nova mensagem pode sair mesmo enquanto se espera resposta da anterior.
        if (conversation.currentState == ConversationState.WAITING_RESPONSE) {
            conversation.transitionTo(ConversationState.IDLE)
        }
        conversation.transitionTo(ConversationState.COMPOSING)
        conversation.transitionTo(ConversationState.PROCESSING)
        conversation.transitionTo(ConversationState.SENDING)

        val message = Message(
            id = UUID.randomUUID().toString(),
            content = text,
            sender = UserMode.COMMUNICATOR,
            timestamp = System.currentTimeMillis(),
            status = MessageStatus.SENDING,
        )
        messages += message
        nearby.sendMessage(WireProtocol.encode(WireMessage.Text(message.id, text)))
        updateStatus(message.id, MessageStatus.SENT)
        estimateOnSend(message.id, text)

        conversation.transitionTo(ConversationState.SENT)
        conversation.transitionTo(ConversationState.WAITING_RESPONSE)
        return true
    }

    /** Matriz Braille: deixa o Comunicador sentir a vibração de uma letra no próprio celular. */
    fun previewLetter(letter: Char) {
        playback.play(letter.toString())
    }

    private fun updateStatus(id: String, status: MessageStatus) {
        val i = messages.indexOfFirst { it.id == id }
        if (i < 0) return
        messages[i] = messages[i].copy(status = status)
        commitActive(listOf(messages[i]))
    }

    private fun onIncomingText(wire: WireMessage.Text) {
        // A mesma mensagem nunca entra duas vezes (a lista usa o id como chave).
        if (wire.id.isNotEmpty() && messages.any { it.id == wire.id }) return
        conversation.transitionTo(ConversationState.RECEIVING)
        val incoming = Message(
            id = wire.id.ifEmpty { UUID.randomUUID().toString() },
            content = wire.text,
            sender = UserMode.DEAFBLIND,
            timestamp = System.currentTimeMillis(),
            status = MessageStatus.DELIVERED,
        )
        messages += incoming
        commitActive(listOf(incoming))
        estimateOnReply()
        conversation.transitionTo(ConversationState.RECEIVED)
        conversation.transitionTo(ConversationState.IDLE)
    }

    private fun onReceived(id: String) {
        val current = messages.firstOrNull { it.id == id }?.status ?: return
        if (current.ordinal < MessageStatus.DELIVERED.ordinal) updateStatus(id, MessageStatus.DELIVERED)
    }

    private fun onProgress(id: String, index: Int) {
        val message = messages.firstOrNull { it.id == id } ?: return
        val text = BrailleTextNormalizer.normalizeForBraille(message.content)
        progress[id] = PlaybackProgress(index, text)
        if (message.status != MessageStatus.PLAYING) updateStatus(id, MessageStatus.PLAYING)
        estimateOnProgress(id, index, message.content)
    }

    private fun onPlayed(id: String) {
        progress.remove(id)
        updateStatus(id, MessageStatus.PLAYED)
        estimateOnPlayed(id)
    }

    /** Conexão caiu: o que não foi confirmado vira "não enviada"; o que vibrava fica como entregue. */
    private fun markInFlightAfterDisconnect() {
        val changed = mutableListOf<Message>()
        for (i in messages.indices) {
            val m = messages[i]
            val next = when (m.status) {
                MessageStatus.SENDING, MessageStatus.SENT -> MessageStatus.FAILED
                MessageStatus.PLAYING -> MessageStatus.DELIVERED
                else -> null
            } ?: continue
            messages[i] = m.copy(status = next)
            changed += messages[i]
        }
        progress.clear()
        chatEstimate = null
        playedAt = null
        if (changed.isNotEmpty()) commitActive(changed)
    }

    /** O celular tátil avisou o nome dele (o que a pessoa de apoio escolheu, ou o da conta Google). */
    private fun onPeerName(name: String) {
        peerName = name
        val id = activeConversationId ?: return
        val i = conversations.indexOfFirst { it.id == id }
        if (i < 0 || conversations[i].peerName == name) return
        // A conversa ativa leva as mensagens ao vivo antes de juntar.
        val live = conversations.map { if (it.id == id) it.copy(messages = messages.toList()) else it }
        val (list, newId) = ConversationMerger.renameActive(live, id, name)
        conversations.clear()
        conversations.addAll(list)
        activeConversationId = newId
        val active = list.first { it.id == newId }
        if (newId != id) {
            messages.clear()
            messages.addAll(active.messages)
            // A conversa que foi absorvida pode já estar na nuvem com o nome antigo: grava o nome
            // novo nela, para a próxima sincronização juntar as duas de novo (e não duplicar).
            if (historyEnabled) live.firstOrNull { it.id == id }?.let { account.push(it.copy(peerName = name), emptyList()) }
        }
        persist(active, if (newId != id) active.messages else emptyList())
    }

    // ───────── Perfil e preferências ─────────

    fun updateMessageStyle(style: MessageStyle) {
        messageStyle = style
        profile.saveMessageStyle(style)
    }

    /** Foto escolhida na galeria: reduz e guarda fora da thread principal. */
    fun setPhoto(uri: Uri) {
        val version = ++photoVersion
        Thread {
            val bitmap = photoStore.save(uri)
            handler.post {
                if (version != photoVersion) return@post // removida ou trocada enquanto salvava
                if (bitmap != null) photo = bitmap.asImageBitmap()
                else banner = Banner(BannerKind.ERROR, "Foto não carregada", "Tente outra imagem.")
            }
        }.start()
    }

    fun removePhoto() {
        photoVersion++
        photo = null
        Thread { photoStore.delete() }.start()
    }

    private var photoVersion = 0

    private fun loadPhotoInBackground() {
        Thread {
            val bitmap = photoStore.load()
            if (bitmap != null) handler.post { photo = bitmap.asImageBitmap() }
        }.start()
    }

    fun rename(name: String) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        profile.saveDisplayName(clean)
        displayName = profile.getDisplayName()
        syncProfile()
        // Conectado: o celular tátil passa a mostrar o nome novo na hora.
        if (connectionState == ConnectionState.CONNECTED) {
            nearby.sendMessage(WireProtocol.encode(WireMessage.Profile(displayName)))
        }
        // Se ainda está procurando, recomeça para o celular tátil ver o nome novo.
        if (nearby.getCurrentState() == ConnectionState.SCANNING) {
            nearby.stop()
            nearby.startAdvertising(displayName)
        }
    }

    fun setAutoSearch(enabled: Boolean) {
        profile.setAutoSearchEnabled(enabled)
        autoSearchEnabled = enabled
        autoReconnect = enabled
        if (enabled) {
            if (started && nearby.getCurrentState() == ConnectionState.DISCONNECTED) nearby.startAdvertising(displayName)
        } else {
            handler.removeCallbacksAndMessages(RECONNECT_TOKEN)
        }
        syncProfile()
    }

    fun setHistory(enabled: Boolean) {
        profile.setHistoryEnabled(enabled)
        historyEnabled = enabled
        if (enabled) archive.saveAll(conversations.toList()) else archive.clear()
        syncProfile()
    }

    /** Nome e preferências do Comunicador na nuvem (só se estiver logado). */
    private fun syncProfile() {
        account.saveProfile(
            displayName,
            mapOf("historyEnabled" to historyEnabled.toString(), "autoSearch" to autoSearchEnabled.toString()),
        )
    }

    /** Apaga tudo deste aparelho e, se estiver logado, também da nuvem. */
    fun clearHistory() {
        val keepActive = conversation(activeConversationId ?: "")?.copy(messages = emptyList(), lastReadAt = 0L)
        messages.clear()
        progress.clear()
        conversations.clear()
        // A conversa com o aparelho conectado continua existindo (vazia), para seguir conversando.
        if (keepActive != null && connectionState == ConnectionState.CONNECTED) conversations.add(keepActive)
        else activeConversationId = null
        archive.clear()
        if (account.isSignedIn) {
            account.deleteCloudData { ok ->
                if (!ok) banner = Banner(BannerKind.ERROR, "Nuvem não apagada", "Confira a internet e tente de novo.")
            }
        }
    }

    // ───────── NearbyListener ─────────

    override fun onMessageReceived(message: String) {
        when (val wire = WireProtocol.decode(message)) {
            is WireMessage.Text -> onIncomingText(wire)
            is WireMessage.Received -> onReceived(wire.id)
            is WireMessage.Progress -> onProgress(wire.id, wire.index)
            is WireMessage.Played -> onPlayed(wire.id)
            is WireMessage.Profile -> onPeerName(wire.name)
            null -> Unit
        }
    }

    override fun onConnectionStatusChanged(status: String) {
        // Texto livre, só para debug. A tela usa o estado formal abaixo.
    }

    override fun onConnectionStateChanged(state: ConnectionState) {
        val wasConnected = connectionState == ConnectionState.CONNECTED
        connectionState = state

        when (state) {
            ConnectionState.CONNECTED -> {
                peerName = nearby.getConnectedEndpointName()?.takeIf { it.isNotBlank() } ?: DEFAULT_PEER
                activateConversationFor(peerName ?: DEFAULT_PEER)
                nearby.sendMessage(WireProtocol.encode(WireMessage.Profile(displayName)))
                hasConnected = true
                autoReconnect = autoSearchEnabled // depois de um pareamento manual, volta à preferência
                banner = Banner(BannerKind.SUCCESS, "Conectado", "Você está conectado com $peerName.")
            }
            ConnectionState.CONNECTION_ERROR -> {
                banner = Banner(BannerKind.ERROR, "Não foi possível conectar", "Tentando de novo.")
                nearby.stop() // vai para DISCONNECTED, que agenda a nova busca
            }
            ConnectionState.DISCONNECTED -> {
                if (wasConnected) {
                    markInFlightAfterDisconnect()
                    banner = Banner(
                        BannerKind.ERROR, "Conexão perdida",
                        if (autoReconnect) "Procurando ${peerName ?: DEFAULT_PEER} de novo." else "Para conectar de novo, toque em Conectar.",
                    )
                }
                peerName = null
                scheduleReconnect()
            }
            else -> Unit
        }
    }

    companion object {
        const val MAX_LENGTH = HapticConfig.MAX_MESSAGE_LENGTH
        /** Nome usado quando o outro aparelho não informa o dele. */
        const val DEFAULT_PEER = "Celular tátil"
        private const val RECONNECT_DELAY_MS = 1500L
        private val RECONNECT_TOKEN = Any()
    }
}
